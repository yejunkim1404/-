# AI 한국어 이름 생성기

출생년도, 성별, 성, 이름 느낌을 기반으로 AI가 한국어 이름을 생성해주는 프로젝트입니다.

## ▶ 실행 방법

1. `.env` 파일 생성
```
OPENAI_API_KEY=당신의_API_KEY
```

2. 필요한 패키지 설치
```
pip install -r requirements.txt
```

3. 실행
```
python main.py
```

